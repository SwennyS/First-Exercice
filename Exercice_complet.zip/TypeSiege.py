# -*-coding:UTF-8 -*
"""Classes pour GROUPE 6
"""
from types import *

class TypeSiege:
	"""Enumeration TypesSiege
	"""
	
	SIMPLE = "SIMPLE"
	ACCOUDOIR = "ACCOUDOIR"
	FAUTEUIL = "FAUTEUIL"
