# -*-coding:UTF-8 -*
"""Classes pour GROUPE 6
"""


class Destination:
	"""Enumeration Destination
	"""
	CLASSE = 1
	BUREAU = 2
	REUNION = 3
