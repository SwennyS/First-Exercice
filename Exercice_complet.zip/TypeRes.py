# -*-coding:UTF-8 -*
"""Classes pour GROUPE 6
"""


class TypeRes:
	"""Enumeration TypesRes
	"""
	ETHERNET = 1
	WIFI = 2
