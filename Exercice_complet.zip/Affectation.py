# -*-coding:UTF-8 -*
"""Classes pour GROUPE 6
"""


class Affectation:
	"""Enumeration Affection
	"""
	ADMINISTRATION = 1
	COURS = 2
