# -*-coding:UTF-8 -*
"""Classes pour GROUPE 6
"""


class CodeCours:
	"""Enumeration CodeCours
	"""
	Francais = 1
	Histoire = 2
	Math = 3
	Philo = 4
	SVT = 5
